import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Questions {
    public static double score;                         //to get the result
    public static double wrong;                         //inheritance
    String incorrect;
    public void MCQ(int number) throws IOException {
        switch (number){

            case 1: {
                try {       //to handle the error

                    System.out.println();
                    System.out.println("------ Java Basics ----- ");
                    File f = new File("MCQ1.csv");
                    Scanner q1 = new Scanner(f);                            // to scan the CSV file
                    while (q1.hasNextLine()) {
                        String line = q1.nextLine();
                        String[] line_array = line.split(",");
                        System.out.println("  ");
                        System.out.println(line_array[0]);                  // to read the CSV file Questions
                        System.out.println(line_array[1]);
                        System.out.println("A. " + line_array[2]);
                        System.out.println("B. " + line_array[3]);
                        System.out.println("C. " + line_array[4]);
                        System.out.println("D. " + line_array[5]);
                        System.out.println();
                          Scanner ques = new Scanner(System.in);
                        System.out.print("Enter your Answer: ");
                         String correctAnswer = ques.nextLine();

                        if (correctAnswer.equalsIgnoreCase( line_array[6])){         //This is the answer of the questions
                            System.out.println("** Your Answer is Correct :D **");
                            score++;
                        }
                        else{
                            System.out.println("Incorrect. :( "+"   The correct Answer is: "+ line_array[6]);
                            wrong++;

                        }




                    }

                }catch (Exception e){
                    e.printStackTrace();
                }
                break;

             }


            case 2: {
                try {

                    System.out.println();
                    System.out.println("------ HTML Basics ----- ");
                    File f = new File("MCQ2.csv");
                    Scanner q1 = new Scanner(f);
                    while (q1.hasNextLine()) {
                        String line = q1.nextLine();
                        String[] line_array = line.split(",");
                        System.out.println("  ");
                        System.out.println(line_array[0]);
                        System.out.println(line_array[1]);
                        System.out.println("A. " + line_array[2]);
                        System.out.println("B. " + line_array[3]);
                        System.out.println("C. " + line_array[4]);
                        System.out.println("D. " + line_array[5]);
                        System.out.println();
                        Scanner ques = new Scanner(System.in);
                        System.out.print("Enter your Answer: ");
                        String correctAnswer = ques.nextLine();
                        if (correctAnswer.equalsIgnoreCase(line_array[6])){
                            System.out.println("** Your Answer is Correct :D **");
                            score++;

                        }
                        else {
                            System.out.println("Incorrect. :( "+"   The correct Answer is: "+ line_array[6]);
                            wrong++;

                        }


                    }

                }catch (Exception e){
                    e.printStackTrace();
                }
                break;
            }
            case 3: {
                try {

                    System.out.println();
                    System.out.println("------ Javascript Basics ----- ");
                    File f = new File("MCQ3.csv");
                    Scanner q1 = new Scanner(f);
                    while (q1.hasNextLine()) {
                        String line = q1.nextLine();
                        String[] line_array = line.split(",");
                        System.out.println("  ");
                        System.out.println(line_array[0]);
                        System.out.println(line_array[1]);
                        System.out.println("A. " + line_array[2]);
                        System.out.println("B. " + line_array[3]);
                        System.out.println("C. " + line_array[4]);
                        System.out.println("D. " + line_array[5]);
                        System.out.println();
                        Scanner ques = new Scanner(System.in);
                        System.out.print("Enter your Answer: ");
                        String correctAnswer = ques.nextLine();
                        if (correctAnswer.equalsIgnoreCase(line_array[6])){
                            System.out.println("** Your Answer is Correct :D **");
                            score++;

                        }
                        else {
                            System.out.println("Incorrect. :( "+"   The correct Answer is: "+ line_array[6]);
                            wrong++;

                        }


                    }

                }catch (Exception e){
                    e.printStackTrace();
                }
            }


        }
    }
}
