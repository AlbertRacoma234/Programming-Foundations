public class Java {
    private String Name;                       //Encapsulation
    private int choice;                     //to access the global variable i use getter and setter method

    public String getName() { return Name;
    }
                                                            // getter and setter method.
                                                            // to get and to set the name
    public void setName(String name) {
        Name = name;
    }
    public int getChoice(){
        return choice;
    }

    public void setChoice(int choice) {
        this.choice = choice;
    }
}
