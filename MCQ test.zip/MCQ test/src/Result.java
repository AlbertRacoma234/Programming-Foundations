import jdk.jfr.Percentage;

public class Result extends Questions{
    double result;
    public void Percentage(){
     result =(score/10)*100;                                                //
        System.out.println(" Total of Correct answer: "+ score);
        System.out.println("Total of Incorrect answer: "+ wrong);
        System.out.println();
        System.out.println("Your Total Result: "+ result +"%");
        System.out.println();                                                  // i use inheritance to gett the result of correct answer and incoorect answer
        if(result >= 50){
            System.out.println("Congratulations You passed the MCQ Test!! :)) ");
        }
        else if(result <= 50){
            System.out.println("Sorry You Failed :(");
        }else{
            System.out.println("Oww noo!! Better Luck Next Time!! ");
        }

    }

}
