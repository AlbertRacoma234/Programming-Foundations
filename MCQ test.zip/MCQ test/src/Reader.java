import java.io.IOException;
import java.util.Scanner;

public class Reader {
    public static void main(String[] args) throws IOException {
        Name();

        Java java = new Java();
        java.setName(Username());       //return

        Choose();
        java.setChoice(UserChoose());

        System.out.println();
        Questions qs = new Questions();  //class
        qs.MCQ(java.getChoice());

        System.out.println();
        Result result = new Result();                  //this is instance method
        System.out.print(java.getName());
        result.Percentage();


    }

    public static void Name(){                                                          //method
        System.out.println("---------------------------------");
        System.out.println("         ****************       ");
        System.out.println("---------*    WELCOME   *--------");
        System.out.println("---------*      To      *--------");
        System.out.println("---------*   MCQ Test   *--------");
        System.out.println("         ****************       ");
        System.out.println("---------------------------------");


    }
    public static void Choose(){
        System.out.println();
        System.out.println("Choose your Multiple Choice Question Set. The Options are:");
        System.out.println("1. Java Basics");
        System.out.println("2. Html Basics");
        System.out.println("3. Javascript Basics");

    }

    public static String Username(){
        Scanner sc = new Scanner(System.in);
        System.out.println();
        System.out.print("Enter Your Name: ");
        String name = sc.nextLine();
        return name;


    }
    public static int UserChoose(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Your MCQ Question set: ");
            int number = sc.nextInt();
            return number;
    }



}
